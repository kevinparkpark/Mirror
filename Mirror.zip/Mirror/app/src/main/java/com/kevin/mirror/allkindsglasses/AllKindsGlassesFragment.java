package com.kevin.mirror.allkindsglasses;

import android.view.View;

import com.kevin.mirror.R;
import com.kevin.mirror.base.BaseFragment;

/**
 * Created by dllo on 16/6/21.
 */
public class AllKindsGlassesFragment extends BaseFragment {

    @Override
    public int setLayout() {
        return R.layout.fragment_allkindsglasses;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
