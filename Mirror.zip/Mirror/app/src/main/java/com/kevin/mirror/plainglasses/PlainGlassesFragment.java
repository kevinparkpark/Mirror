package com.kevin.mirror.plainglasses;

import android.view.View;

import com.kevin.mirror.R;
import com.kevin.mirror.base.BaseFragment;

/**
 * Created by dllo on 16/6/21.
 */
public class PlainGlassesFragment extends BaseFragment{

    @Override
    public int setLayout() {
        return R.layout.fragment_plainglasses;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
