package com.kevin.mirror.mainpage;

import android.view.View;

import com.kevin.mirror.R;
import com.kevin.mirror.base.BaseFragment;

/**
 * Created by kevin on 16/6/21.
 */
public class SpecialFragment extends BaseFragment{
    @Override
    public int setLayout() {
        return R.layout.fragment_allkinds;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
