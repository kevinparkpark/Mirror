package com.kevin.mirror.mainpage.maininterface;

/**
 * Created by kevin on 16/6/21.
 */
public interface MenuOnClickListener {
    void onMenuClickListener(int position);
}
