package com.kevin.mirror.utils;

/**
 * Created by kevin on 16/6/25.
 */
public class WelcomeBean {

    /**
     * text : &quot;雪屋&quot;07号
     * img : http://image.mirroreye.cn/108041a4a0be25dd37eee04582888eabe381.jpg
     */

    private String text;
    private String img;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
