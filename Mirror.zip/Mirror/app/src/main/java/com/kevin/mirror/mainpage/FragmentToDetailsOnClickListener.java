package com.kevin.mirror.mainpage;

/**
 * Created by kevin on 16/6/22.
 */
public interface FragmentToDetailsOnClickListener {
    void onFragmentToDetailsClickListener(int position);
}
